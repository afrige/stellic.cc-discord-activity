(() => {
  const endpoint = "http://127.0.0.1:17392/activity";
  let lastSent = "";
  let sending = false;

  async function reportPage() {
    if (sending || !location.hostname.toLowerCase().endsWith("stellic.cc")) return;
    const payload = { title: document.title || "Stellic", url: location.href };
    const signature = JSON.stringify(payload);
    if (signature === lastSent) return;
    sending = true;
    try {
      const response = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: signature
      });
      if (response.ok) lastSent = signature;
    } catch {
      // The desktop app may not be running yet. A later check retries.
    } finally {
      sending = false;
    }
  }

  reportPage();
  setInterval(reportPage, 2500);
  new MutationObserver(reportPage).observe(document.documentElement, {
    subtree: true, childList: true, characterData: true
  });

  let previousUrl = location.href;
  setInterval(() => {
    if (location.href !== previousUrl) {
      previousUrl = location.href;
      lastSent = "";
      reportPage();
    }
  }, 1000);
})();
